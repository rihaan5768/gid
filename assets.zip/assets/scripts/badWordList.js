localList = [

    'ass',
    'bastard',
    'bitch',
    'cock',
    'cunt',
    'dildo',
    'douche',
    'douchebag',
    'fag',
    'fuck',
    'hell',
    'masterbate',
    'nigger;',
    'orgasm',
    'penis',
    'pussy',
    'shit',
    'vagina',
    'whore'
];