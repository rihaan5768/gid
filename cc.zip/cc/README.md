# Cookie-Clicker-Unblocked
2.052 unblocked<br>
Credits obviously go Orteil, visit the official website here: http://orteil.dashnet.org/cookieclicker/

List of domains this is accessible.

| Link                                     | Accessible w/ Lightspeed |
|------------------------------------------|--------------------------|
| https://ccported.github.io/CookieClicker | ✅                       |
