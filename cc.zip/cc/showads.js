//this lets us detect adblockers so we can adjust the layout in case ads aren't shown ! (we're not using this for anything weird, promise !)
//this works because an adblocker will usually block this file from being embedded at all


// Edit by sojs: setting this to false to prevent ads in general. 
// I will roll a pre-game add each time the game loads and every, say, 30 minutes or so. All funds going directly to funding
// large number of domains.
var showAds=false;//true;
